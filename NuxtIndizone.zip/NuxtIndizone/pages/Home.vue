<template>
  <div>

   
    <Header />

     <!-- Home Page Main Section  -->
    <div class="max-w-[1108px] flex flex-wrap-reverse xl:flex-col xxl:flex-row items-center justify-center mx-auto p-4">

      <div
        class="flex flex-col md:max-w-[76%] justify-center space-y-7  max-w-[85%] xxl:max-w-[450px] mt-[10%] xxl:mt-[127px] ">
        <p
          class=" text-[31px] md:text-[49px] xl:text-[61px] text-[#1a2933] leading-tight xxl:text-left text-center font-['Montserrat'] not-italic font-bold tracking-[-0.02em]">
          Gemeinsam für deinen Laden</p>
        <p class="max-w-[800px] xxl:text-left text-center font-['Montserrat'] font-normal text-[16px] leading-[1.5rem]">
          Verbinde dich mit deiner lokalen Gemeinschaft und präsentiert eure Produkte ohne Aufwand online -
          mit
          IndieZone, der online Plattform für den Einzelhandel.</p>

        <div class="text-center xxl:text-start">
          <button type="button"
            class="mt-[2%] xl:mt-[5%] text-[#ffffff] items-center bg-[#1a2933] font-['Montserrat'] text-[15px] xl:text-[20px] font-medium rounded-lg w-[223px] xl:w-[308px] h-[48px] xl:h-[56px] text-center mx-auto leading-[1.2rem]">Starte
            in deine Zukunft</button>
        </div>

        <p
          class="text-[#1A293361] items-center xxl:text-start text-center font-['Montserrat'] font-normal text-[16px] leading-[1.5rem]">
          &gt;87% der befragten lokalen Einzelhändler sind <br> begeistert von IndieZone</p>
      </div>
      <!---- <div>
       <img src="assets/Seitenverhältnis.svg" alt="" class=" xs:w-[272px] xs:h-[272px]  sm:w-[363px] h-[363px]  md:w-[720px] md:h-[720px]  xl:w-[600px] xl:h-[600px]">
      </div>-->
      <div>
        <img src="../assets/img/HomePageImg.svg" alt="" class="max-w-[100%] xl:max-w-[600px]">
      </div>

    </div>
    <Service/>
    <Introduction/>
    <HomeButton/>
    <OurMission/>
    <HowItWorks/>
    <Faq/>
    <Footer />
    
    
  </div>
</template>
  
<script>
import Header from '@/Components/Header.vue';
import Footer from '@/Components/Footer.vue';
import Service from '@/Components/Service.vue';
import Introduction from '@/Components/Introduction.vue';
import HomeButton from '@/Components/HomeButton.vue';
import OurMission from '@/Components/OurMission.vue';
import HowItWorks from '@/Components/HowItWorks.vue';
import Faq from  '@/Components/Faq.vue';
import Contact from '@/pages/ContactUs.vue'


export default {
  components: {
    Header,
    Footer,
    Service,
    Introduction,
    HomeButton,
    OurMission,
    HowItWorks,
    Faq,
    Contact

  },
};
</script>
  
