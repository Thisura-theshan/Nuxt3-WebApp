<template>
    <div>
        <!-- Contact section -->
        <section class="w-full font-sans">
            <div class="relative mx-auto w-full max-w-5xl md:-mt-52">
                <!-- Message section -->
                <div
                    class="w-full md:relative md:-bottom-72 p-8 md:ml-14 flex items-end flex-col bg-[#1a2933] md:mt-10 md:max-w-xs md:rounded-lg">
                    <h2 class="text-2xl md:text-4xl text-[#99d100] font-bold text-right mb-7">
                        <span class="block">Wir freuen uns</span>
                        <span class="block"> auf deine Nachricht!</span>
                    </h2>
                    <div class="flex flex-row items-center text-xl text-[#99d100] font-bold underline gap-4 mb-3">
                        <a href="#">info@indiezone.de</a>
                        <img class="h-6" src="../assets/img/mail (1).png" alt="mail-image" />
                    </div>
                    <div class="flex flex-row items-center text-xl text-[#99d100] font-bold underline gap-4">
                        <a href="#">linkedin/IndieZone</a>
                        <img class="h-7 w-7" src="../assets/img/Linkdin.png" alt="linkedin-image" />
                    </div>
                </div>


                <!-- Contact form section -->
                <div class="flex flex-col p-8 shadow-lg my-4 rounded-lg md:p-14">
                    <h2 class="text-xl font-normal mb-8 text-darkGreen md:text-right md:mb-20 md:text-2xl">
                        Schreibe uns direkt:
                    </h2>
                    <form action="#">
                        <div class="flex flex-col gap-4">
                            <input
                                class="w-full md:max-w-xs lg:max-w-md self-end bg-[#ecf0f1] h-12 shadow-inner rounded-lg px-2 outline-none"
                                aria-label="name" type="text" name="name" id="name" placeholder="Name" />
                            <input
                                class="w-full md:max-w-xs lg:max-w-md self-end bg-[#ecf0f1] h-12 shadow-inner rounded-lg px-2 outline-none"
                                aria-label="email" type="email" name="email" id="email" placeholder="Mail-Adresse" />
                            <textarea class="w-full bg-[#ecf0f1] shadow-inner rounded-lg p-2 outline-none max-h-96"
                                aria-label="message" name="message" id="message" cols="50" rows="10"
                                placeholder="Nachricht"></textarea>
                            <input
                                class="flex self-end font-bold text-[#ffff] bg-[#1a2933] rounded-lg w-fit py-3 px-8 cursor-pointer active:scale-95 hover:opacity-90"
                                type="submit" value="Senden" />
                        </div>
                    </form>
                </div>

               <Footer/>
            </div>
        </section>
    </div>
</template>

<script>
export default {
    data() {
        return {
            message: 'Hello from MyComponent!',
        };
    },
};
</script>