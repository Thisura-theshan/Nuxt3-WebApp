<template>
  <div>
    <nuxtlayout>
      <NuxtPage/>
    </nuxtlayout> 
  </div>
</template>
