<template>
    <div>
        <!-- Our Mission -->

        <div>
            <div class="max-w-[1108px]  items-center  mx-auto mt-[25%] ">
                <div class=" text-black font-['Montserrat'] xxl:max-w-[700px] sm:max-w-[70%] xl:max-w-[70%] pl-4 z-10">
                    <p class="py-8 text-[32px] font-bold md:text-[45px] xl:text-[48px] leading-5 text-[#1a2933] ">Unsere
                        Mission</p>
                    <p class="md:font-semibold md:text-[13px] xl:text-[24px] leading-8 text-[#1a2933]  mt-4">Den lokalen
                        Einzelhandel stärken,
                        einzigartige, lokal produzierte Produkte und nachhaltigen Konsum fördern.</p>
                    <p class="font-normal text-[16px] leading-5 underline py-4">Mehr über uns</p>
                </div>

            </div>

            <div
                class="   xxl:max-w-[1200px] xxl:h-[10525] flex flex-wrap items-center justify-end mx-auto mt-[30%] xl:mt-[24%]">
                <div class="absolute">
                    <img src="../assets/img/Ourmission.svg" class="xl:w-[100%] xl:h-[917px] " alt="">
                </div>

            </div>

        </div>

    </div>
</template>


<script>
export default {
    data() {
        return {
            message: 'Hello from MyComponent!',
        };
    },
};
</script>
  