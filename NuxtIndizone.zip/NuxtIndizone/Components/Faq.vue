<template>
    <div>

        <!-- FAQ Section -->

        <div class="max-w-[1200px]  mx-auto   xxl:mt-[6%]">
            <div class=" bgsvgs imgbg font-['Montserrat'] "
                >
                <p
                    class="  hidden xl:block font-bold text-[49px] leading-5 text-center tracking-wide text-[#ffffff]  md:pt-[400px] xl:pt-[40%] xxl:pt-[33%] ">
                    Häufige Fragen
                    (FAQ)</p>
                <p
                    class=" pt-[90%] mb-14 xl:hidden font-bold text-[49px] leading-5 text-center tracking-wide text-[#ffffff] md:pt-[60%] ">
                    (FAQ)</p>



                <div class=" mx-auto px-5  min-h-sceen mt-[7%] mb-24 space-y-8  ">

                    <div class="grid divide-y divide-neutral-200 xl:max-w-[65%] mx-auto ">
                        <div class="">
                            <details class="group">
                                <summary
                                    class=" bg-[#ffff] text-[#1a2933] font-semibold  py-4 px-4 rounded-md flex justify-between items-center text-[16px] xl:text-[24px] md:leading-5 cursor-pointer list-none">
                                    <span>Muss ich Produkte hochladen?</span>

                                    <span class="transition group-open:rotate-180">
                                        <svg fill="none" height="24" shape-rendering="geometricPrecision"
                                            stroke="currentColor" stroke-linecap="round" stroke-linejoin="round"
                                            stroke-width="1.5" viewBox="0 0 24 24" width="24">
                                            <path d="M6 9l6 6 6-6"></path>
                                        </svg>
                                    </span>
                                </summary>

                                <p class="max-w-[90%] py-6 ml-[8%] text-right text-[#ffff]   group-open:animate-fadeIn">
                                    IndieZone bietet dir volle Transparenz über deinen Erfolg. Mit nur einem Blick auf
                                    deine Händlerseite siehst du, wie viele Kunden durch uns zu dir gefunden haben. So
                                    kannst du jederzeit sehen, dass IndieZone sich für dich lohnt.
                                </p>

                            </details>
                        </div>
                    </div>

                    <div class="grid divide-y divide-neutral-200 xl:max-w-[65%] mx-auto ">
                        <div class="">
                            <details class="group">
                                <summary
                                    class=" bg-[#ffff] text-[#1a2933] font-semibold  py-4 px-4 rounded-md flex justify-between items-center text-[16px] xl:text-[24px] md:leading-5 cursor-pointer list-none">
                                    <span>Was kostet IndieZone?</span>

                                    <span class="transition group-open:rotate-180">
                                        <svg fill="none" height="24" shape-rendering="geometricPrecision"
                                            stroke="currentColor" stroke-linecap="round" stroke-linejoin="round"
                                            stroke-width="1.5" viewBox="0 0 24 24" width="24">
                                            <path d="M6 9l6 6 6-6"></path>
                                        </svg>
                                    </span>
                                </summary>

                                <p class="max-w-[90%] py-6 ml-[8%] text-right text-[#ffff]  group-open:animate-fadeIn">
                                    IndieZone bietet dir volle Transparenz über deinen Erfolg. Mit nur einem Blick auf
                                    deine Händlerseite siehst du, wie viele Kunden durch uns zu dir gefunden haben. So
                                    kannst du jederzeit sehen, dass IndieZone sich für dich lohnt.
                                </p>

                            </details>
                        </div>
                    </div>

                    <div class="grid divide-y divide-neutral-200 xl:max-w-[65%] mx-auto ">
                        <div class="">
                            <details class="group">
                                <summary
                                    class=" bg-[#ffff] text-[#1a2933] font-semibold  py-4 px-4 rounded-md flex justify-between items-center text-[16px] md:text-[24px] md:leading-5 cursor-pointer list-none">
                                    <span>Ist die Voranmeldung verbindlich?</span>

                                    <span class="transition group-open:rotate-180">
                                        <svg fill="none" height="24" shape-rendering="geometricPrecision"
                                            stroke="currentColor" stroke-linecap="round" stroke-linejoin="round"
                                            stroke-width="1.5" viewBox="0 0 24 24" width="24">
                                            <path d="M6 9l6 6 6-6"></path>
                                        </svg>
                                    </span>
                                </summary>

                                <p class="max-w-[90%] py-6 ml-[8%] text-right text-[#ffff]  group-open:animate-fadeIn">
                                    IndieZone bietet dir volle Transparenz über deinen Erfolg. Mit nur einem Blick auf
                                    deine Händlerseite siehst du, wie viele Kunden durch uns zu dir gefunden haben. So
                                    kannst du jederzeit sehen, dass IndieZone sich für dich lohnt.
                                </p>

                            </details>
                        </div>
                    </div>
                </div>

                <p class="font-semibold text-[16px] xl:text-[31px] leading-5 text-center  text-[#ffffff]  ">Noch nicht alle
                    Fragen
                    beantwortet?</p>

                <div class=" flex justify-center">
                    <button type="button"
                        class="mt-[5%]  drop-shadow-lg text-black  bg-[#ffff]   font-['Montserrat']  font-bold text-[13px] xl:text-[20px]   rounded-lg  w-[280px] h-[56px] text-center mr-3 md:mr-0 leading-[1.2rem] ">Jetzt
                        direkt Fragen</button>
                </div>

                <!-- Start become  -->-
                <div class="flex flex-col  space-y-4  font-['Montserrat']  items-center mt-[30%] ">
                    <div class="text-center flex flex-col space-y-4 max-w-[944px]">
                        <p class="font-normal text-[16px] leading-6 text-[#ffff]">Werde Teil der IndieZone</p>
                        <p class="font-semibold text-[30px] leading-10 text-[#ffff] lear-both">Registriere dich direkt und
                            mache den nächsten Schritt. Werde Teil der wachsenden
                            Gemeinschaft
                            und
                            gestalte den Einzelhandel der Zukunft. </p>

                        <p class=" pt-6 font-semibold text-[30px] leading-10 text-[#ffff] lear-both">Einfach. Fair.
                            Effektiv.</p>

                    </div>

                    <div class=" flex justify-center">
                        <button type="button"
                            class="mt-[8%]  drop-shadow-lg text-black  bg-[#ffff]   font-['Montserrat']  font-bold text-[20px] w-[260px]  rounded-lg md:w-[300px] xl:w-[320px] h-[86px] text-center mr-3 md:mr-0 leading-[1.2rem] ">Jetzt
                            direkt Fragen</button>
                    </div>


                </div>

            </div>


        </div>

</div>

</template>


<script>
export default {
    data() {
        return {
            message: 'Hello from MyComponent!',
        };
    },
};
</script>

<style>
     .bgsvgs{
        background-image: url("../assets/img/faqsection.svg");
        height: 2000px;
    }
</style>