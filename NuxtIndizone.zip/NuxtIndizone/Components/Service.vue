<template>
      <!--Service Section -->
      <div class="max-w-[1108px]  pt-[16%] mx-auto">
            <div>
                <p
                    class=" xl:leading-5 tracking-widest text-[31px] xl:text-[49px] text-center font-bold mx-auto  font-['Montserrat']  ">
                    Sei endlich
                    erfolgreich online</p>
            </div>

            <div
                class="flex flex-col xl:flex-row justify-center items-center xl:space-x-11  xxl:justify-between xxl:space-y-0 xl:space-y-0 space-y-9 mt-[15%] ">

                <div
                    class="rounded-md xxl:max-w-[284px] xxl:h-[188px] xs:w-[270px] xs:h-[284px] sm:max-w-[340px] sm:h-[260px] md:max-w-[400px] md:w-[400px] md:h-[236px]  bg-[#f6f7f7] xxl:bg-[#ffffff] xl:w-[243px] xl:h-[342px] shadow-lg xxl:shadow-none flex flex-col justify-center items-center">

                    <div class="flex flex-col xxl:flex-row xxl:space-x-4 mx-auto">
                        <div class="">
                            <img class="w-[64px] h-[64px] xxl:w-[48px] xxl:h-[48px]" src="../assets/img/Service1.svg" alt="">
                        </div>
                        <div>
                            <p
                                class="pt-[50%] xs:pb-3 sm:pb-2 md:pb-3 xl:pt-[32px] xxl:pt-[12px] font-['Montserrat'] font-bold text-[16px] leading-5 text-[#1a2933]">
                                Einfach
                            </p>
                        </div>
                    </div>
                    <div>
                        <p
                            class="text-center font-normal leading-6 text-[#1a2933] text-[16px] font-['Montserrat'] xl:pt-2 xl:pb-[60px]">
                            Ohne Vorkenntnisse dank unkomplizierter Bedienung. Wir kümmern uns um Design, SEO, das
                            komplette Marketing und und und...
                        </p>
                    </div>
                </div>

                <div
                    class="rounded-md xxl:max-w-[284px] xxl:h-[188px] xs:w-[270px] xs:h-[284px] sm:max-w-[340px] sm:h-[260px] md:max-w-[400px] md:w-[400px] md:h-[236px]  bg-[#f6f7f7] xxl:bg-[#ffffff] xl:w-[243px] xl:h-[342px] shadow-lg xxl:shadow-none flex flex-col justify-center items-center">

                    <div class="flex flex-col xxl:flex-row xxl:space-x-4 mx-auto">
                        <div class="">
                            <img class="w-[64px] h-[64px] xxl:w-[48px] xxl:h-[48px]" src="../assets/img/Service2.svg" alt="">
                        </div>
                        <div>
                            <p
                                class="pt-[50%] xs:pb-3 sm:pb-2 md:pb-3 xl:pt-[32px] xxl:pt-[12px] font-['Montserrat'] font-bold text-[16px] leading-5 text-[#1a2933]">
                                Einfach
                            </p>
                        </div>
                    </div>
                    <div>
                        <p
                            class="text-center font-normal leading-6 text-[#1a2933] text-[16px] font-['Montserrat'] xl:pt-2 xl:pb-[60px]">
                            Ohne Vorkenntnisse dank unkomplizierter Bedienung. Wir kümmern uns um Design, SEO, das
                            komplette Marketing und und und...
                        </p>
                    </div>
                </div>

                <div
                    class="rounded-md xxl:max-w-[284px] xxl:h-[188px] xs:w-[270px] xs:h-[284px] sm:max-w-[340px] sm:h-[260px] md:max-w-[400px] md:w-[400px] md:h-[236px]  bg-[#f6f7f7] xxl:bg-[#ffffff] xl:w-[243px] xl:h-[342px] shadow-lg xxl:shadow-none flex flex-col justify-center items-center">

                    <div class="flex flex-col xxl:flex-row xxl:space-x-4 mx-auto">
                        <div class="">
                            <img class="w-[64px] h-[64px] xxl:w-[48px] xxl:h-[48px]" src="../assets/img/Service3.svg" alt="">
                        </div>
                        <div>
                            <p
                                class="pt-[50%] xs:pb-3 sm:pb-2 md:pb-3 xl:pt-[32px] xxl:pt-[12px] font-['Montserrat'] font-bold text-[16px] leading-5 text-[#1a2933]">
                                Einfach
                            </p>
                        </div>
                    </div>
                    <div>
                        <p
                            class="text-center font-normal leading-6 text-[#1a2933] text-[16px] font-['Montserrat'] xl:pt-2 xl:pb-[60px]">
                            Ohne Vorkenntnisse dank unkomplizierter Bedienung. Wir kümmern uns um Design, SEO, das
                            komplette Marketing und und und...
                        </p>
                    </div>
                </div>

            </div>
     </div>
</template>

<script>
export default {
    data() {
        return {
            message: 'Hello from MyComponent!',
        };
    },
};
</script>
  