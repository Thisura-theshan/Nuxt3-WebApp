<template>
    <div>
        <div class="flex justify-center mt-[8%]">
            <button type="button"
                class=" absolute text-[#ffffff]  bg-[#1a2933]   font-['Montserrat'] text-[13px] xxl:font-bold xxl:text-[20px]   font-medium rounded-lg xs:w-[194px]  xs:h-[48px] xxl:w-[308px] xxl:h-[56px] text-center mr-3 md:mr-0 leading-[1.2rem] ">Starte
                in deine Zukunft</button>
        </div>
    </div>
</template>


<script>
export default {
    data() {
        return {
            message: 'Hello from MyComponent!',
        };
    },
};
</script>
