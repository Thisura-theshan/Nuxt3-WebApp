<template>
    <div>
        <!-- How it works -->
        <div class="max-w-[1108px] flex-warp items-center justify-between mx-auto mt-[40%]  font-['Montserrat']">
            <p
                class=" mt-[70%] xxl:mt-1 text-2xl font-bold text-center xxl:text-left text:[32px] md:text-[49px] leading-5 text-[#1a2933] tracking-wide">
                Wie es funktioniert</p>

            <div class="flex flex-col space-y-[15%] mt-[10%]">

                <div
                    class="flex space-y-24 flex-col xl:flex-col-reverse xxl:flex-row items-center  justify-between mx-auto   ">

                    <img class="h-auto max-w-[57%]   xl:mt-[10%]  " src="../assets/img/Procees1.jpg"
                        alt="image description">

                    <div class=" font-['Montserrat'] px-2 xl:px-0 max-w-[420px]   ">

                        <p class="font-bold text-[25px] xl:leading-6 ">Registrieren und Shop eröffnen</p>
                        <p class="font-light text-[15px] leading-6 mt-4">Wir wissen, wie wichtig Zeit für euch ist.
                            Deshalb ist die Shop-Eröffnung super einfach und schnell gemacht. In wenigen Schritten hast
                            du deinen Online-Shop eingerichtet und erreichst sofort neue Kunden und Kundinnen.
                        </p>
                    </div>
                </div>

                <div
                    class=" flex space-y-24 flex-col xl:flex-col-reverse xxl:flex-row items-center  justify-between mx-auto   ">

                   

                    <div class=" font-['Montserrat'] px-2 xl:px-0 max-w-[420px]   ">

                        <p class="font-bold text-[25px] xl:leading-6 ">Registrieren und Shop eröffnen</p>
                        <p class="font-light text-[15px] leading-6 mt-4">Wir wissen, wie wichtig Zeit für euch ist.
                            Deshalb ist die Shop-Eröffnung super einfach und schnell gemacht. In wenigen Schritten hast
                            du deinen Online-Shop eingerichtet und erreichst sofort neue Kunden und Kundinnen.
                        </p>
                    </div>

                    <img class="h-auto max-w-[57%]   xl:mt-[10%]  " src="../assets/img/Process2.svg"
                        alt="image description">
                </div>

                <div
                    class="flex space-y-24 flex-col xl:flex-col-reverse xxl:flex-row items-center  justify-between mx-auto   ">

                    <img class="h-auto max-w-[57%]   xl:mt-[10%]  " src="../assets/img/Process3.svg"
                        alt="image description">

                    <div class=" font-['Montserrat'] px-2 xl:px-0 max-w-[420px]   ">

                        <p class="font-bold text-[25px] xl:leading-6 ">Registrieren und Shop eröffnen</p>
                        <p class="font-light text-[15px] leading-6 mt-4">Wir wissen, wie wichtig Zeit für euch ist.
                            Deshalb ist die Shop-Eröffnung super einfach und schnell gemacht. In wenigen Schritten hast
                            du deinen Online-Shop eingerichtet und erreichst sofort neue Kunden und Kundinnen.
                        </p>
                    </div>
                </div>



                <div
                    class="flex space-y-24 flex-col xl:flex-col-reverse xxl:flex-row items-center  justify-between mx-auto   ">

                   

                    <div class=" font-['Montserrat'] px-2 xl:px-0 max-w-[420px]   ">

                        <p class="font-bold text-[25px] xl:leading-6 ">Registrieren und Shop eröffnen</p>
                        <p class="font-light text-[15px] leading-6 mt-4">Wir wissen, wie wichtig Zeit für euch ist.
                            Deshalb ist die Shop-Eröffnung super einfach und schnell gemacht. In wenigen Schritten hast
                            du deinen Online-Shop eingerichtet und erreichst sofort neue Kunden und Kundinnen.
                        </p>
                    </div>

                    <img class="h-auto max-w-[57%]   xl:mt-[10%]  " src="../assets/img/Process4.svg"
                        alt="image description">
                </div>

            </div>

        </div>

    </div>
</template>

<script>
export default {
    data() {
        return {
            message: 'Hello from MyComponent!',
        };
    },
};
</script>
  