<template>
    <div>

        <div class="mt-[30%]">
            <footer class="relative mx-auto w-full max-w-[1200px] md:-mt-52 ">

                <div class="flex flex-col-reverse md:flex-row md:flex-1 md:justify-between p-8  lg:px-0 mt-20">

                    <div class="flex justify-between md:flex-1 xxl:max-w-[40%] flex-wrap pt-10 xl:max-w-[45%] xxl:pt-0">
                        <div class="flex flex-col gap-2">
                            <img class="w-24 h-24 mb-6" src="../assets/img/FooterLogo.svg" alt="logo" />
                            <h4 class="text-darkGreen text-sm cursor-pointer">Impressum</h4>
                            <h4 class="text-darkGreen text-sm cursor-pointer">
                                Datenschutz
                            </h4>
                        </div>
                        <div class="flex flex-col gap-2">
                            <h3 class="text-darkGreen text-base font-semibold mb-4">
                                Inhalte
                            </h3>
                            <h2 class="text-darkGreen text-sm cursor-pointer">
                                Für Kunden/Kundinnen
                            </h2>
                            <h2 class="text-darkGreen text-sm cursor-pointer">
                                Für Händler:innen
                            </h2>
                            <h2 class="text-darkGreen text-sm cursor-pointer">Über uns</h2>
                            <h2 class="text-darkGreen text-sm cursor-pointer">
                                Voranmelden
                            </h2>
                            <h2 class="text-darkGreen text-sm cursor-pointer">Kontakt</h2>
                        </div>
                    </div>

                    <div class="max-w-[380px]">
                        <div class="flex flex-col md:ml-14">
                            <h3 class="font-semibold text-base text-[#1a2933]">
                                Händler:innen-Newsletter Anmeldung
                            </h3>
                            <form action="">
                                <div class="relative flex">
                                    <input
                                        class="w-full bg-[#ecf0f1] h-12 shadow-inner rounded-lg px-2 outline-none my-5 md:max-w-sm pr-8"
                                        aria-label="newsletter-email" type="email" name="newsletter-email"
                                        id="newsletter-email" placeholder="Mail-Adresse" />
                                    <button type="submit" class="absolute right-0 top-0 h-full">
                                        <img class="w-6 mr-5" src="../assets/img/Polygon.svg" alt="sendmail" />
                                    </button>
                                </div>
                            </form>


                            <div class="flex gap-3">
                                <input class="accent-linkBlue cursor-pointer" aria-label="newsletter-agree" type="checkbox"
                                    name="newsletter-agree" id="newsletter-agree" />
                                <p class="text-xs text-darkGreen font-normal">
                                    Ich nehme die
                                    <a class="text-[#0968c0]" href="#">Datenschutzhinweise</a> zur
                                    Kenntnis.
                                </p>
                            </div>
                            <p class="text-[#1a2933] text-opacity-40 text-sm mt-5 max-w-sm">
                                Abboniere unseren Newsletter und bleibe so immer über uns
                                informiert.
                            </p>

                        </div>
                    </div>


                </div>

                <hr />
                <div class="flex p-8 flex-col-reverse md:flex-row md:justify-between md:items-center lg:px-0">
                    <div class="flex gap-5 mt-4">
                        <img class="w-28" src="../assets/img/Footersvg2.svg" alt="efre-logo" />

                        <p class="text-xs text-darkGreen">
                            Wir werden gefördert von der Europäischen Union
                        </p>
                    </div>
                    <span class="text-xs text-darkGreen text-right">© IndieZone 2023 designed by Klara Prettl</span>
                </div>
            </footer>
        </div>
    </div>
</template>