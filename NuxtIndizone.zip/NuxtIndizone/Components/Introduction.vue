<template>
    <div
        class="  mt-[-15%] myelement max-w-[1200px]  mx-auto  pt-[7%]  w-full xxl:h-[2180px]  xxl:mt-[15%]  xxl:w-[1300px] xs:h-[3300px] md:h-[3500px] bgsvg  xxl:bg-[url('../assets/img/Vector.svg')] ">

        <div class="  flex justify-center">
            <p
                class="  text-[#ffffff] text-[31px] sm:max-w-[400px] xs:max-w-[200px] xl:text-[49px] xs:mt-[400px]  xl:max-w-[600px] text-center font-['Montserrat'] font-bold md:mt-[60%] xxl:mt-[6%] ">
                Warum
                IndieZone? </p>
        </div>

        <div class="flex flex-col space-y-[160px] ">

            <div
                class="flex max-w-full px-5 xl:px-40 xxl:px-0  xxl:max-w-[95%]   xxl:flex-row  xl:flex-col-reverse flex-col xxl:justify-between  items-center  ">
                <div class="mt-14 mb-16">
                    <img class="w-[600px] " src="../assets/img/Intropic1.svg" alt="">
                </div>
                <div class="text-[#ffffff] max-w-full xxl:max-w-[48%]  xxl:px-4 ">
                    <p class="font-bold text-[25px] leading-6 ">Werde gefunden</p>
                    <p class="md:text-[15px] text-[13px] leading-6 font-normal pt-[16px]">Unser Marktplatz verbindet
                        lokale Läden und Geschäfte in deiner Umgebung. Neue Kunden werden deinen Laden und deine
                        Produkte endlich finden und zwar da wo sie suchen: online. Mit IndieZone als Partner
                        erreichst du ohne Vorkenntnisse und großen Aufwand neue Kundinnen und ergänzt deine lokale
                        Präsenz gezielt online. Die Kunden kaufen dabei trotzdem vor Ort bei dir im Laden.</p>
                </div>
            </div>

            <div
                class=" xxl:ml-14 flex max-w-full  xl:px-40 xxl:px-0 xxl:max-w-[95%] xxl:flex-row flex-col-reverse xl:flex-col xxl:justify-between items-center">

                <div class="text-end xxl:text-left px-5 text-[#ffffff] max-w-full xxl:max-w-[48%] xxl:px-4">
                    <p class="font-bold text-[25px] leading-6">Werde gefunden</p>

                    <p class="md:text-[15px] text-[13px] leading-6 font-normal pt-[16px]">Unser Marktplatz verbindet lokale
                        Läden und Geschäfte in deiner Umgebung. Neue Kunden werden deinen Laden und deine Produkte endlich
                        finden und zwar da wo sie suchen: online. Mit IndieZone als Partner erreichst du ohne Vorkenntnisse
                        und großen Aufwand neue Kundinnen und ergänzt deine lokale Präsenz gezielt online. Die Kunden kaufen
                        dabei trotzdem vor Ort bei dir im Laden.</p>
                </div>

                <div class="mt-14 mb-16 flex justify-end">
                    <img class="w-[600px]" src="../assets/img/Intropic2.svg" alt="">
                </div>
            </div>


            <div
                class="flex max-w-full xl:px-40 xxl:px-0  xxl:max-w-[95%]   xxl:flex-row  xl:flex-col-reverse flex-col xxl:justify-between  items-center  ">
                <div class="mt-14 mb-16">
                    <img class="w-[600px] " src="../assets/img/IntroPic3.svg" alt="">
                </div>
                <div class="text-[#ffffff] px-5 max-w-full xxl:max-w-[48%]  xxl:px-4 ">
                    <p class="font-bold   text-[25px] leading-6 ">Werde gefunden</p>
                    <p class="md:text-[15px] text-[13px] leading-6 font-normal pt-[16px]">Unser Marktplatz verbindet
                        lokale Läden und Geschäfte in deiner Umgebung. Neue Kunden werden deinen Laden und deine
                        Produkte endlich finden und zwar da wo sie suchen: online. Mit IndieZone als Partner
                        erreichst du ohne Vorkenntnisse und großen Aufwand neue Kundinnen und ergänzt deine lokale
                        Präsenz gezielt online. Die Kunden kaufen dabei trotzdem vor Ort bei dir im Laden.</p>
                </div>
            </div>

        </div>

    </div>
</template>


<script>
export default {
    data() {
        return {
            message: 'Hello from MyComponent!',
        };
    },
};
</script>
  
<style>
/* styles.css */
@media (max-width: 1280px) {

    /* CSS rules for screens with a maximum width of 1250px or less */
    .myelement {
        clip-path: polygon(100% 8%, 100% 89%, 0 100%, 0 13%);
        /* Other styles for the element */

        /* Adjust the value as needed */
        background-color: #1a2933;
    }

}

/* CSS rules for screens with a maximum width of 1280px or higher */
@media screen and (min-width: 1280px) {

    /* For example: */
    .bgsvg{
        background-image: url("../assets/img/Vector.svg");
    }

    /* Add more CSS rules as needed */
}
</style>